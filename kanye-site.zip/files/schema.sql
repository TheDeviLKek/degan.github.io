PRAGMA foreign_keys = ON;
DROP TABLE IF EXISTS tracks;
DROP TABLE IF EXISTS albums;
DROP TABLE IF EXISTS quotes;
DROP TABLE IF EXISTS impact_facts;
DROP TABLE IF EXISTS samples;
DROP TABLE IF EXISTS stats;

CREATE TABLE albums (
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL,
  era TEXT NOT NULL, color TEXT NOT NULL, blurb TEXT NOT NULL
);
CREATE TABLE tracks (
  id INTEGER PRIMARY KEY, album_id INTEGER NOT NULL REFERENCES albums(id) ON DELETE CASCADE,
  track_no INTEGER NOT NULL, title TEXT NOT NULL,
  note REAL NOT NULL,                 -- основная нота (Гц) для синтезированной демо-версии
  preview_url TEXT NOT NULL DEFAULT '' -- путь к вашему mp3-отрывку, напр. /static/audio/stronger.mp3
);
CREATE TABLE quotes (
  id INTEGER PRIMARY KEY, kind TEXT NOT NULL CHECK (kind IN ('quote','idea')),
  text TEXT NOT NULL, context TEXT NOT NULL
);
CREATE TABLE impact_facts (
  id INTEGER PRIMARY KEY, year INTEGER NOT NULL, title TEXT NOT NULL,
  body TEXT NOT NULL, era TEXT NOT NULL
);
CREATE TABLE samples (
  id INTEGER PRIMARY KEY, kanye_track TEXT NOT NULL, kanye_year INTEGER NOT NULL,
  original_artist TEXT NOT NULL, original_title TEXT NOT NULL, original_year INTEGER NOT NULL,
  transformation TEXT NOT NULL
);
CREATE TABLE stats (
  key TEXT PRIMARY KEY, label TEXT NOT NULL, value INTEGER NOT NULL, suffix TEXT NOT NULL DEFAULT ''
);

INSERT INTO quotes (kind,text,context) VALUES
 ('quote','I feel like I''m too busy writing history to read it.','Широко цитируемая фраза; атрибуция приблизительная'),
 ('quote','Everything you do in life stems from either fear or love.','Приписывается Канье; проверьте источник перед публикацией'),
 ('quote','My greatest pain in life is that I will never be able to see myself perform live.','Широко цитируемая фраза; атрибуция приблизительная'),
 ('quote','People always say that you can''t please everybody. I think that''s a cop-out.','Из интервью; атрибуция приблизительная'),
 ('idea','Каждый альбом начинается с чистого листа: прошлый звук нельзя повторять.','Пересказ философии, не цитата'),
 ('idea','Ограничения звучат смелее изобилия: убрать лишнее значит услышать главное.','Пересказ эпохи Yeezus и Donda, не цитата'),
 ('idea','Релиз не точка, а черновик: альбом можно менять, пока слушатели в комнате.','Пересказ подхода The Life of Pablo, не цитата'),
 ('idea','Мода, музыка и архитектура части одной сцены: звук рождается вместе с образом.','Пересказ общей идеи, не цитата');

INSERT INTO impact_facts (year,title,body,era) VALUES
 (2004,'Соул на повышенном питче','Ускоренные вокальные сэмплы стали фирменным приёмом и сменили жёсткий гангстерский звук на личную, узнаваемую интонацию.','soul'),
 (2007,'Хип-хоп выходит на стадионы','Graduation сделал электронику и синтезаторы нормой для хип-хоп-мейнстрима, а рэпер получил звук для огромных залов.','pop'),
 (2008,'Автотюн как эмоция','808s & Heartbreak превратил автотюн из эффекта в язык уязвимости и заложил основу мелодичного рэпа и эмо-хип-хопа.','autotune'),
 (2010,'Максимализм как манифест','MBDTF собрал оркестры, хоры и десятки авторов в один альбом и поднял планку студийной амбиции жанра.','max'),
 (2013,'Индастриал вместо хитов','Yeezus ушёл от мелодичности к шуму и минимализму и показал, что мейнстрим-альбом может звучать агрессивно и без сингла.','industrial'),
 (2016,'Альбом как живой документ','The Life of Pablo менялся после релиза, а стриминг перестал быть только каналом доставки и стал частью творческого процесса.','gospel'),
 (2021,'Госпел-минимализм и событие','Donda соединила хор, электронику и прослушивания на стадионах: релиз стал большим публичным событием.','gospel');

INSERT INTO samples (kanye_track,kanye_year,original_artist,original_title,original_year,transformation) VALUES
 ('Through the Wire',2003,'Chaka Khan','Through the Fire',1984,'Вокал ускорен и поднят по высоте, баллада превратилась в живой исповедальный хип-хоп-хук.'),
 ('Gold Digger',2005,'Ray Charles','I Got a Woman',1954,'Госпел-ритм-н-блюз переупакован в минималистичный бит с узнаваемым семплом-хуком.'),
 ('Stronger',2007,'Daft Punk','Harder, Better, Faster, Stronger',2001,'Электронный френч-хаус превращён в стадионный хип-хоп-гимн с жёстким ударным.'),
 ('Devil in a New Dress',2010,'Smokey Robinson','Will You Love Me Tomorrow',1973,'Мягкое соул-вступление переходит в тяжёлый, неторопливый бит.'),
 ('Power',2010,'King Crimson','21st Century Schizoid Man',1969,'Прог-рок-рифф стал мрачным каркасом хип-хоп-гимна.'),
 ('Bound 2',2013,'Ponderosa Twins Plus One','Bound',1971,'Тёплый соул-хук оставлен почти без изменений на фоне резкого минимализма Yeezus.');

INSERT INTO stats (key,label,value,suffix) VALUES
 ('grammy','Премий Grammy',24,''),
 ('nominations','Номинаций на Grammy',75,''),
 ('records','Проданных записей по оценкам прессы',160,' млн+');
