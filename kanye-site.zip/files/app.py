import hmac
import os
import re
import sqlite3
from functools import wraps
from urllib.parse import unquote

from flask import Flask, Response, jsonify, g, abort, request, send_from_directory
from markupsafe import escape
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.utils import secure_filename

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "kanye.db")
app = Flask(__name__, static_folder="static", static_url_path="/static")
app.json.ensure_ascii = False
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024  # mp3 до 40 МБ
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)  # правильные https-ссылки за прокси хостинга


def init_db():
    import seed
    with sqlite3.connect(DB_PATH) as conn, open(os.path.join(BASE, "schema.sql"), encoding="utf-8") as f:
        conn.executescript(f.read())
        seed.run(conn)


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


def rows(sql, args=()):
    return [dict(r) for r in db().execute(sql, args).fetchall()]


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/albums")
def albums_page():
    return send_from_directory(app.static_folder, "albums.html")


@app.route("/influence")
def influence_page():
    return send_from_directory(app.static_folder, "influence.html")


@app.route("/api/discography")
def discography():
    data = rows("SELECT * FROM albums ORDER BY year, id")
    for alb in data:
        alb["tracks"] = rows("SELECT * FROM tracks WHERE album_id = ? ORDER BY track_no", (alb["id"],))
    return jsonify(data)


@app.route("/api/albums")
def albums():
    return jsonify(rows("SELECT * FROM albums ORDER BY year"))


@app.route("/api/tracks/<int:album_id>")
def tracks(album_id):
    data = rows("SELECT * FROM tracks WHERE album_id = ? ORDER BY track_no", (album_id,))
    if not data:
        abort(404, description="Альбом не найден")
    return jsonify(data)


@app.route("/api/quote")
def quote():
    exclude = request.args.get("exclude", type=int, default=-1)
    data = rows("SELECT * FROM quotes WHERE id != ? ORDER BY RANDOM() LIMIT 1", (exclude,))
    return jsonify(data[0] if data else {})


@app.route("/api/timeline")
def timeline():
    return jsonify(rows("SELECT * FROM impact_facts ORDER BY year"))


@app.route("/api/samples")
def samples():
    return jsonify(rows("SELECT * FROM samples ORDER BY kanye_year"))


@app.route("/api/stats")
def stats():
    return jsonify(rows("SELECT * FROM stats"))


AUDIO_DIR = os.path.join(BASE, "static", "audio")
os.makedirs(AUDIO_DIR, exist_ok=True)


def admin_ok():
    key = os.environ.get("ADMIN_KEY")
    if key:  # на хостинге: обязательный ключ
        return hmac.compare_digest(unquote(request.headers.get("X-Admin-Key", "")).encode("utf-8"), key.encode("utf-8"))
    # без ключа: только с этого компьютера, без прокси-заголовков; X-Admin-Request защищает от CSRF с чужих сайтов
    proxied = any(h in request.headers for h in ("X-Forwarded-For", "Forwarded", "X-Real-Ip"))
    return request.remote_addr in ("127.0.0.1", "::1") and not proxied and request.headers.get("X-Admin-Request") == "1"


def admin_only(fn):
    @wraps(fn)
    def wrap(*args, **kwargs):
        if not admin_ok():
            return jsonify(error="Доступ запрещён: задайте ADMIN_KEY или откройте админку с этого компьютера"), 403
        return fn(*args, **kwargs)
    return wrap


def save_audio(f):
    base, ext = os.path.splitext(f.filename or "")
    ext = ext.lower()
    if ext not in (".mp3", ".m4a", ".ogg", ".wav"):
        return None
    name, n = secure_filename(base) or "track", 1
    fname = name + ext
    while os.path.exists(os.path.join(AUDIO_DIR, fname)):
        n += 1
        fname = f"{name}-{n}{ext}"
    f.save(os.path.join(AUDIO_DIR, fname))
    return "/static/audio/" + fname


def write(sql, args=()):
    with sqlite3.connect(DB_PATH) as c:
        return c.execute(sql, args).lastrowid


@app.route("/album/<int:aid>")
def album_page(aid):
    return send_from_directory(app.static_folder, "album.html")


@app.route("/admin")
def admin_page():
    return send_from_directory(app.static_folder, "admin.html")


@app.route("/quiz")
def quiz_page():
    return send_from_directory(app.static_folder, "quiz.html")


@app.route("/story")
def story_page():
    return send_from_directory(app.static_folder, "story.html")


@app.route("/compare")
def compare_page():
    return send_from_directory(app.static_folder, "compare.html")


@app.route("/favorites")
def favorites_page():
    return send_from_directory(app.static_folder, "favorites.html")


@app.route("/api/album/<int:aid>")
def album_full(aid):
    found = rows("SELECT * FROM albums WHERE id = ?", (aid,))
    if not found:
        return jsonify(error="not found"), 404
    alb = found[0]
    alb["tracks"] = rows("SELECT * FROM tracks WHERE album_id = ? ORDER BY track_no", (aid,))
    try:
        alb["notes"] = rows("SELECT label, text FROM album_notes WHERE album_id = ?", (aid,))
    except sqlite3.OperationalError:
        alb["notes"] = []
    return jsonify(alb)


@app.route("/api/search")
def search():
    q = request.args.get("q", "").strip().lower()
    if len(q) < 2:
        return jsonify([])
    hit = lambda *xs: any(q in (x or "").lower() for x in xs)
    out = []
    for r in rows("SELECT id, title, year, blurb FROM albums ORDER BY year, id"):
        if hit(r["title"], r["blurb"]):
            out.append(dict(t="album", id=r["id"], title=r["title"], sub=str(r["year"])))
    for r in rows("SELECT t.id, t.album_id, t.title, a.title AS album FROM tracks t JOIN albums a ON a.id = t.album_id ORDER BY a.year, t.track_no"):
        if hit(r["title"]):
            out.append(dict(t="track", id=r["album_id"], tid=r["id"], title=r["title"], sub=r["album"]))
    for r in rows("SELECT text, context FROM quotes"):
        if hit(r["text"], r["context"]):
            out.append(dict(t="quote", title=r["text"][:90], sub=r["context"] or ""))
    for r in rows("SELECT title, body, year FROM impact_facts ORDER BY year"):
        if hit(r["title"], r["body"]):
            out.append(dict(t="fact", title=r["title"], sub=str(r["year"])))
    return jsonify(out[:30])


@app.route("/api/admin/preview", methods=["POST"])
@admin_only
def admin_preview():
    url = save_audio(request.files["file"]) if "file" in request.files else None
    if not url:
        return jsonify(error="Нужен файл mp3, m4a, ogg или wav"), 400
    write("UPDATE tracks SET preview_url = ? WHERE id = ?", (url, int(request.form["track_id"])))
    return jsonify(ok=True, preview_url=url)


@app.route("/api/admin/track", methods=["POST"])
@admin_only
def admin_track():
    aid, f = int(request.form["album_id"]), request.files.get("file")
    url = save_audio(f) if f and f.filename else ""
    if url is None:
        return jsonify(error="Формат файла: mp3, m4a, ogg или wav"), 400
    n = rows("SELECT COALESCE(MAX(track_no), 0) + 1 AS n FROM tracks WHERE album_id = ?", (aid,))[0]["n"]
    tid = write("INSERT INTO tracks (album_id, track_no, title, note, preview_url) VALUES (?,?,?,?,?)",
                (aid, n, request.form["title"].strip(), 146.8, url))
    return jsonify(ok=True, id=tid)


@app.route("/api/admin/album", methods=["POST"])
@admin_only
def admin_album():
    f = request.form
    aid = write("INSERT INTO albums (title, year, era, color, blurb) VALUES (?,?,?,?,?)",
                (f["title"].strip(), int(f["year"]), f.get("era", "soul"), f.get("color") or "#7b6cff", f.get("blurb", "").strip()))
    return jsonify(ok=True, id=aid)


@app.route("/api/admin/quote", methods=["POST"])
@admin_only
def admin_quote():
    f = request.form
    write("INSERT INTO quotes (kind, text, context) VALUES (?,?,?)", (f.get("kind", "quote"), f["text"].strip(), f.get("context", "").strip()))
    return jsonify(ok=True)


def site_base():
    return (os.environ.get("SITE_URL") or request.host_url).rstrip("/")


PAGES = {
    "/": ("Эра Ye: как Канье Уэст переписал звук поколения", "Дискография, архитектура влияния, викторина и сравнение альбомов: интерактивный проект о Канье Уэсте."),
    "/albums": ("Дискография: все альбомы и треки — Эра Ye", "Все альбомы и треки, поиск и фильтры по звуку."),
    "/influence": ("Архитектура влияния — Эра Ye", "Интерактивная карта: кто и через какой трек связан с Канье, плюс «машина времени»."),
    "/story": ("История Канье: жизнь, музыка, споры — Эра Ye", "Хронология: от рождения до новых альбомов, с громкими заявлениями и скандалами."),
    "/quiz": ("Викторина по дискографии — Эра Ye", "Угадай альбом, год или оригинал сэмпла: 10 вопросов, 15 секунд на ответ."),
    "/compare": ("Сравнение альбомов — Эра Ye", "Два альбома рядом: год, треки, звук, гости и история."),
    "/favorites": ("Избранное — Эра Ye", "Плейлист из любимых треков."),
}


@app.after_request
def inject_meta(resp):
    """Превью ссылок (Open Graph) и значок сайта для всех HTML-страниц."""
    if resp.status_code != 200 or resp.mimetype != "text/html" or request.path.startswith("/static/"):
        return resp
    title, desc = PAGES.get(request.path, PAGES["/"])
    image = "/static/og.jpg"
    m = re.match(r"^/album/(\d+)$", request.path)
    if m:
        found = rows("SELECT title, year, blurb FROM albums WHERE id = ?", (int(m.group(1)),))
        if found:
            title, desc = f"{found[0]['title']} ({found[0]['year']}) — Эра Ye", found[0]["blurb"]
            if os.path.exists(os.path.join(app.static_folder, "og", f"album-{m.group(1)}.jpg")):
                image = f"/static/og/album-{m.group(1)}.jpg"
    base, t, d = site_base(), escape(title), escape(desc)
    tags = (
        '<link rel="icon" href="/static/favicon.svg" type="image/svg+xml"><meta name="theme-color" content="#050508">'
        f'<meta name="description" content="{d}"><meta property="og:type" content="website"><meta property="og:site_name" content="Эра Ye">'
        f'<meta property="og:title" content="{t}"><meta property="og:description" content="{d}">'
        f'<meta property="og:url" content="{base}{request.path}"><meta property="og:image" content="{base}{image}">'
        '<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">'
        '<meta name="twitter:card" content="summary_large_image">'
    )
    if request.path.startswith("/admin"):
        tags += '<meta name="robots" content="noindex">'
    resp.direct_passthrough = False
    resp.set_data(resp.get_data(as_text=True).replace("</head>", tags + "\n</head>", 1))
    for h in ("ETag", "Last-Modified"):
        resp.headers.pop(h, None)
    resp.headers["Cache-Control"] = "no-cache"
    return resp


SPOTIFY_LINK = re.compile(r"(track|album)[/:]([A-Za-z0-9]{22})")


def ensure_columns(conn):
    for table in ("tracks", "albums"):
        if "spotify_id" not in {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN spotify_id TEXT")


@app.route("/api/admin/spotify", methods=["POST"])
@admin_only
def admin_spotify():
    """Ссылки на треки альбома (по одной на строку, в порядке альбома) -> spotify_id у треков."""
    aid, text = int(request.form["album_id"]), request.form.get("links", "")
    start = max(1, int(request.form.get("start") or 1)) - 1
    found = SPOTIFY_LINK.findall(text)
    track_ids, album_ids = [i for k, i in found if k == "track"], [i for k, i in found if k == "album"]
    tr = rows("SELECT id FROM tracks WHERE album_id = ? ORDER BY track_no", (aid,))
    with sqlite3.connect(DB_PATH) as c:
        for row, sid in zip(tr[start:], track_ids):
            c.execute("UPDATE tracks SET spotify_id = ? WHERE id = ?", (sid, row["id"]))
        if album_ids:
            c.execute("UPDATE albums SET spotify_id = ? WHERE id = ?", (album_ids[0], aid))
    return jsonify(ok=True, mapped=max(0, min(len(tr) - start, len(track_ids))), links=len(track_ids), tracks=len(tr), album=bool(album_ids))


@app.route("/api/admin/spotify_track", methods=["POST"])
@admin_only
def admin_spotify_track():
    m = SPOTIFY_LINK.search(request.form.get("url", ""))
    if not m or m.group(1) != "track":
        return jsonify(error="Нужна ссылка на трек Spotify вида open.spotify.com/track/…"), 400
    write("UPDATE tracks SET spotify_id = ? WHERE id = ?", (m.group(2), int(request.form["track_id"])))
    return jsonify(ok=True)


@app.route("/api/admin/spotify_clear", methods=["POST"])
@admin_only
def admin_spotify_clear():
    aid = int(request.form["album_id"])
    with sqlite3.connect(DB_PATH) as c:
        c.execute("UPDATE tracks SET spotify_id = NULL WHERE album_id = ?", (aid,))
        c.execute("UPDATE albums SET spotify_id = NULL WHERE id = ?", (aid,))
    return jsonify(ok=True)


@app.route("/robots.txt")
def robots():
    return Response(f"User-agent: *\nDisallow: /admin\nDisallow: /api/admin/\nSitemap: {site_base()}/sitemap.xml\n", mimetype="text/plain")


@app.route("/sitemap.xml")
def sitemap():
    urls = ["/", "/albums", "/story", "/influence", "/quiz", "/compare"] + [f"/album/{r['id']}" for r in rows("SELECT id FROM albums ORDER BY year, id")]
    body = "".join(f"<url><loc>{site_base()}{u}</loc></url>" for u in urls)
    return Response('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + body + "</urlset>", mimetype="application/xml")


@app.errorhandler(404)
def not_found(err):
    return jsonify(error=getattr(err, "description", "Не найдено")), 404


if not os.path.exists(DB_PATH):
    init_db()

if not os.path.exists(DB_PATH):
    init_db()
with sqlite3.connect(DB_PATH) as _c:  # заметки к альбомам (добавятся и в старую базу)
    import seed
    seed.add_notes(_c)
    ensure_columns(_c)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
