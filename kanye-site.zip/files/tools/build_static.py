"""Статическая выгрузка сайта для GitHub Pages: создаёт папку docs/.
Запуск из папки проекта:  py tools/build_static.py https://ВАШ-НИК.github.io
(адрес нужен для красивых превью ссылок; без него сайт всё равно работает)."""
import json
import os
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)
site = (sys.argv[1] if len(sys.argv) > 1 else "").rstrip("/")
if site:
    os.environ["SITE_URL"] = site

import app  # noqa: E402  (после настройки SITE_URL)

OUT = os.path.join(ROOT, "docs")
shutil.rmtree(OUT, ignore_errors=True)
os.makedirs(OUT)
shutil.copytree(os.path.join(ROOT, "static"), os.path.join(OUT, "static"),
                ignore=shutil.ignore_patterns("*.html", "admin.js", "__pycache__"))
client = app.app.test_client()


def write(rel, text):
    path = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def page(route, rel):
    html = client.get(route).get_data(as_text=True)
    write(rel, html.replace("<head>", "<head>\n  <script>window.STATIC_SITE = true;</script>", 1))


def data(name, route):
    write(f"data/{name}.json", json.dumps(client.get(route).get_json(), ensure_ascii=False))


with app.app.app_context():
    ids = [r["id"] for r in app.rows("SELECT id FROM albums ORDER BY year, id")]
    write("data/quotes.json", json.dumps(app.rows("SELECT * FROM quotes"), ensure_ascii=False))

for route, rel in [("/", "index.html"), ("/albums", "albums.html"), ("/story", "story.html"), ("/influence", "influence.html"),
                   ("/quiz", "quiz.html"), ("/compare", "compare.html"), ("/favorites", "favorites.html")]:
    page(route, rel)
for i in ids:
    page(f"/album/{i}", f"album/{i}/index.html")
    data(f"album-{i}", f"/api/album/{i}")
    data(f"tracks-{i}", f"/api/tracks/{i}")
for name in ("albums", "discography", "samples", "timeline", "stats"):
    data(name, f"/api/{name}")
write("robots.txt", client.get("/robots.txt").get_data(as_text=True))
write("sitemap.xml", client.get("/sitemap.xml").get_data(as_text=True))
write("404.html", '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
      '<title>Страницы нет — Эра Ye</title><link rel="stylesheet" href="/static/styles.css"></head><body><main class="pg">'
      '<p class="kicker">404</p><h1 class="shine">Такой страницы нет</h1><p class="muted">Вернитесь на <a class="more" href="/">главную</a>.</p></main></body></html>')
write(".nojekyll", "")
print(f"Готово: папка docs ({len(ids)} альбомов). Адрес для превью: {site or 'не задан'}")
