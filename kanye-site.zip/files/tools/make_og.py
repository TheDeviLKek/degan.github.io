"""Картинки для превью ссылок: static/og.jpg и static/og/album-<id>.jpg.
Запуск из папки проекта: python tools/make_og.py  (нужен Pillow: pip install pillow).
Перезапускайте после добавления альбомов."""
import os
import sqlite3

from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = next((p for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "C:/Windows/Fonts/arialbd.ttf",
                         "/System/Library/Fonts/Supplemental/Arial Bold.ttf") if os.path.exists(p)), None)
W, H = 1200, 630


def font(size):
    return ImageFont.truetype(FONT, size) if FONT else ImageFont.load_default()


def wrap(d, text, f, width):
    out, line = [], ""
    for word in text.split():
        t = (line + " " + word).strip()
        if d.textlength(t, font=f) > width and line:
            out.append(line)
            line = word
        else:
            line = t
    return out + [line]


def glow(im, xy, r, color, alpha):
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).ellipse([xy[0] - r, xy[1] - r, xy[0] + r, xy[1] + r], fill=color + (alpha,))
    im.alpha_composite(layer.filter(ImageFilter.GaussianBlur(r / 2.2)))


def save(im, name):
    im.convert("RGB").save(os.path.join(ROOT, "static", name), quality=88)


def site():
    im = Image.new("RGBA", (W, H), "#050508")
    glow(im, (900, 300), 300, (123, 108, 255), 110)
    face = Image.open(os.path.join(ROOT, "static", "face.jpg")).convert("L")
    side, fh = 560, face.height
    face = face.crop(((face.width - fh) // 2, 0, (face.width - fh) // 2 + fh, fh)).resize((side, side))
    mask = Image.radial_gradient("L").resize((side, side)).point(lambda v: max(0, 255 - int(v * 1.3)))
    im.paste(face.convert("RGBA"), (610, 35), mask)
    d = ImageDraw.Draw(im)
    d.text((70, 70), "ЭРА YE", font=font(30), fill=(157, 146, 255))
    y = 150
    for line in wrap(d, "Он переписал звук целого поколения", font(68), 520):
        d.text((70, y), line, font=font(68), fill=(236, 236, 230))
        y += 82
    d.text((70, 530), "Дискография · Карта влияния · Викторина", font=font(26), fill=(138, 138, 146))
    save(im, "og.jpg")


def album(a):
    c = tuple(int(a["color"].lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
    im = Image.new("RGBA", (W, H), "#050508")
    glow(im, (850, 315), 330, c, 120)
    d = ImageDraw.Draw(im)
    x0, y0, sq = 690, 115, 400
    d.ellipse([x0 + 130, y0 + 10, x0 + 130 + sq - 20, y0 + sq - 10], fill=(18, 18, 22), outline=(70, 70, 80))
    cx, cy = x0 + 130 + (sq - 20) // 2, y0 + sq // 2
    for r in range(40, 190, 14):
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(42, 42, 50))
    d.ellipse([cx - 28, cy - 28, cx + 28, cy + 28], fill=c)
    cover = Image.new("RGB", (sq, sq))
    cd = ImageDraw.Draw(cover)
    for y in range(sq):
        t = y / sq
        cd.line([(0, y), (sq, y)], fill=tuple(int(ch * (1 - t * 0.9)) for ch in c))
    cd.text((26, 20), str(a["year"]), font=font(96), fill=(20, 20, 20))
    im.paste(cover, (x0, y0))
    d.text((70, 70), "ЭРА YE", font=font(30), fill=(157, 146, 255))
    d.text((70, 150), str(a["year"]), font=font(40), fill=c)
    y = 215
    for line in wrap(d, a["title"], font(70), 560):
        d.text((70, y), line, font=font(70), fill=(236, 236, 230))
        y += 84
    d.text((70, 530), "Альбом · треклист, гости, история", font=font(26), fill=(138, 138, 146))
    save(im, f"og/album-{a['id']}.jpg")


if __name__ == "__main__":
    os.makedirs(os.path.join(ROOT, "static", "og"), exist_ok=True)
    site()
    con = sqlite3.connect(os.path.join(ROOT, "kanye.db"))
    con.row_factory = sqlite3.Row
    for row in con.execute("SELECT id, title, year, color FROM albums"):
        album(row)
    print("готово: static/og.jpg и static/og/album-*.jpg")
