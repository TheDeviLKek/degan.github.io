"""Локальный просмотр папки docs/ так, как её покажет GitHub Pages: py tools/preview_static.py  ->  http://127.0.0.1:8000"""
import http.server
import os
import socketserver

DOCS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs")


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DOCS, **kwargs)

    def translate_path(self, path):
        p = super().translate_path(path)
        return p + ".html" if not os.path.exists(p) and os.path.exists(p + ".html") else p  # /albums -> albums.html


if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("127.0.0.1", 8000), Handler) as srv:
        print("Открой http://127.0.0.1:8000  (Ctrl+C: остановить)")
        srv.serve_forever()
