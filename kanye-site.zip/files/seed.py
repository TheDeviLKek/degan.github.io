"""Полная дискография и доп. контент. Вызывается из app.init_db()."""
NOTES = [110, 123.5, 138.6, 146.8, 164.8, 185, 196, 220]  # ноты для демо-синтеза

ALBUMS = [  # название, год, эпоха, цвет, описание, треки через |
 ("The College Dropout", 2004, "soul", "#d9b36b", "Сэмплы соула на повышенном питче и личная лирика вместо гангстерских клише.",
  "Intro|We Don't Care|Graduation Day|All Falls Down|I'll Fly Away|Spaceship|Jesus Walks|Never Let Me Down|Get Em High|Workout Plan|The New Workout Plan|Slow Jamz|Breathe In Breathe Out|School Spirit Skit 1|School Spirit|School Spirit Skit 2|Lil Jimmy Skit|Two Words|Through the Wire|Family Business|Last Call"),
 ("Late Registration", 2005, "soul", "#b98a4e", "Оркестровый соул с Джоном Брайоном: струнные, живые инструменты и хиты вроде Gold Digger.",
  "Wake Up Mr. West|Heard 'Em Say|Touch the Sky|Gold Digger|Skit #1|Drive Slow|My Way Home|Crack Music|Roses|Bring Me Down|Addiction|Skit #2|Diamonds from Sierra Leone|We Major|Hey Mama|Celebration|Skit #3|Gone|Diamonds from Sierra Leone (Remix)|Late"),
 ("Graduation", 2007, "pop", "#ff4fd8", "Стадионный электро-хип-хоп: синтезаторы, огромные хуки, конец эпохи сэмплов.",
  "Good Morning|Champion|Stronger|I Wonder|Good Life|Can't Tell Me Nothing|Barry Bonds|Drunk and Hot Girls|Flashing Lights|Everything I Am|The Glory|Homecoming|Big Brother|Bittersweet Poetry"),
 ("808s & Heartbreak", 2008, "autotune", "#4fd8ff", "Автотюн как инструмент эмоции и драм-машина 808 вместо привычных хип-хоп-битов.",
  "Say You Will|Welcome to Heartbreak|Heartless|Amazing|Love Lockdown|Paranoid|RoboCop|Street Lights|Bad News|See You in My Nightmares|Coldest Winter|Pinocchio Story"),
 ("My Beautiful Dark Twisted Fantasy", 2010, "max", "#ffd24f", "Максимализм: оркестры, десятки гостей и одержимость деталями в студии.",
  "Dark Fantasy|Gorgeous|POWER|All of the Lights (Interlude)|All of the Lights|Monster|So Appalled|Devil in a New Dress|Runaway|Hell of a Life|Blame Game|Lost in the World|Who Will Survive in America"),
 ("Watch the Throne", 2011, "max", "#e0b84a", "Совместный альбом с Jay-Z: роскошь, бит-эксперименты и стадионный размах.",
  "No Church in the Wild|Lift Off|Ni**as in Paris|Otis|Gotta Have It|New Day|That's My B****|Welcome to the Jungle|Who Gon Stop Me|Murder to Excellence|Made in America|Why I Love You|Illest Motherf**ker Alive|H•A•M|Primetime|The Joy"),
 ("Yeezus", 2013, "industrial", "#ff3b30", "Индастриал, жёсткий шум и минимализм: альбом без сингла и без обложки.",
  "On Sight|Black Skinhead|I Am a God|New Slaves|Hold My Liquor|I'm in It|Blood on the Leaves|Guilt Trip|Send It Up|Bound 2"),
 ("The Life of Pablo", 2016, "gospel", "#7bffb0", "Хор, гость на каждом треке и релиз как живой документ с правками после выхода.",
  "Ultralight Beam|Father Stretch My Hands Pt. 1|Father Stretch My Hands Pt. 2|Famous|Feedback|Low Lights|Highlights|Freestyle 4|I Love Kanye|Waves|FML|Real Friends|Wolves|Frank's Track|Siiiiiiiiilver Surffffeeeer Intermission|30 Hours|No More Parties in LA|Facts (Charlie Heat Version)|Fade|Saint Pablo"),
 ("Ye", 2018, "soul", "#f2e6b8", "Семь треков, записанных в Вайоминге: сырые семплы, исповедь и «живая» подача.",
  "I Thought About Killing You|Yikes|All Mine|Wouldn't Leave|No Mistakes|Ghost Town|Violent Crimes"),
 ("Kids See Ghosts", 2018, "autotune", "#6fe0d0", "Совместный проект с Kid Cudi: психоделика, хоровые эффекты и компактный, плотный звук.",
  "Feel the Love|Fire|4th Dimension|Freee (Ghost Town Pt. 2)|Reborn|Kids See Ghosts|Cudi Montage"),
 ("Jesus Is King", 2019, "gospel", "#b6ff7b", "Госпел-альбом о вере: хоровые аранжировки, орган и сухой, сжатый звук.",
  "Every Hour|Selah|Follow God|Closed on Sunday|On God|Everything We Need|Water|God Is|Hands On|Use This Gospel|Jesus Is Lord"),
 ("Donda", 2021, "gospel", "#e8e8e2", "Монохромный госпел-минимализм и прослушивания на стадионах.",
  "Donda Chant|Jail|God Breathed|Off the Grid|Hurricane|Praise God|Jonah|Ok Ok|Junya|Believe What I Say|24|Remote Control|Moon|Heaven and Hell|Donda|Keep My Spirit Alive|Jesus Lord|New Again|Tell the Vision|Lord I Need You|Pure Souls|Come to Life|No Child Left Behind|Jail Pt 2|Ok Ok Pt 2|Junya Pt 2|Jesus Lord Pt 2"),
 ("Vultures 1", 2024, "industrial", "#ff6a3d", "Совместный альбом ¥$ с Ty Dolla $ign: жёсткие биты, искажённые вокалы и много гостей.",
  "Stars|King|Fuk Sumn|Vultures|Carnival|Beg Forgiveness|Problematic|Back to Me|Hoodrat|Do It|Paperwork|Burn|F**kin Up the Friendship|Keys to My Life|Good (Don't Die)|Talking"),
]

IDEAS = [  # пересказы принципов, не цитаты
 ("Звук часть образа: обложка, одежда и сцена работают как продолжение трека.", "Пересказ подхода к альбомам и мерчу, не цитата"),
 ("Сэмпл это разговор с прошлым: его нужно перевернуть так, чтобы он зазвучал по-новому.", "Пересказ подхода раннего периода, не цитата"),
 ("Шум и грубая фактура могут быть сильнее идеальной полировки.", "Пересказ эпохи Yeezus, не цитата"),
 ("Хор делает личное общим: одинокая исповедь становится ритуалом.", "Пересказ госпел-периода, не цитата"),
 ("Технику (автотюн, 808) стоит подчинять эмоции, а не наоборот.", "Пересказ эпохи 808s & Heartbreak, не цитата"),
 ("Масштаб тоже высказывание: прослушивание на стадионе превращает релиз в событие.", "Пересказ эпохи Donda, не цитата"),
 ("Идея, не доведённая за недели, остывает: скорость бывает творческим методом.", "Пересказ сессий в Вайоминге, не цитата"),
 ("Гости это палитра: много голосов делают альбом объёмнее.", "Пересказ подхода MBDTF и Pablo, не цитата"),
]

FACTS = [
 (2001, "Продюсер раньше рэпера", "Работа над The Blueprint Jay-Z, включая «Izzo (H.O.V.A.)», вывела его в первые ряды продюсеров и открыла путь к сольной карьере.", "soul"),
 (2005, "Оркестровый соул", "Late Registration, записанный вместе с Джоном Брайоном, добавил в хип-хоп струнные и живые инструменты.", "soul"),
 (2011, "Роскошь как жанр", "Watch the Throne с Jay-Z превратил совместный альбом в событие и задал эстетику «люксового» рэпа.", "max"),
 (2015, "Музыка и мода: одна сцена", "С 2015 года линейка Yeezy x Adidas показала, что артист может строить бренд, равный музыке по масштабу.", "pop"),
 (2018, "Пять альбомов за пять недель", "Сессии в Вайоминге дали Ye, Kids See Ghosts и работы для Pusha T, Nas и Teyana Taylor: быстрый конвейер релизов.", "soul"),
 (2019, "Госпел на большом экране", "Jesus Is King вышел вместе с одноимённым фильмом для IMAX: релиз как мультимедийное событие.", "gospel"),
]

SAMPLES = [
 ("Touch the Sky", 2005, "Curtis Mayfield", "Move On Up", 1970, "Бодрый духовой рифф оригинала стал взрывным вступлением хип-хоп-хита."),
 ("Diamonds from Sierra Leone", 2005, "Shirley Bassey", "Diamonds Are Forever", 1971, "Драматичные струнные из бондовской темы превращены в тяжёлый хип-хоп-хук."),
 ("Lost in the World", 2010, "Bon Iver", "Woods", 2009, "Вокал в автотюне из «Woods» стал эмоциональным ядром финала альбома."),
]


def run(conn):
    for i, (title, year, era, color, blurb, tr) in enumerate(ALBUMS, 1):
        conn.execute("INSERT INTO albums VALUES (?,?,?,?,?,?)", (i, title, year, era, color, blurb))
        for n, t in enumerate(tr.split("|"), 1):
            conn.execute("INSERT INTO tracks (album_id,track_no,title,note,preview_url) VALUES (?,?,?,?,'')",
                         (i, n, t, NOTES[(i * 3 + n) % len(NOTES)]))
    conn.executemany("INSERT INTO quotes (kind,text,context) VALUES ('idea',?,?)", IDEAS)
    conn.executemany("INSERT INTO impact_facts (year,title,body,era) VALUES (?,?,?,?)", FACTS)
    conn.executemany("INSERT INTO samples (kanye_track,kanye_year,original_artist,original_title,original_year,transformation) VALUES (?,?,?,?,?,?)", SAMPLES)
    conn.execute("INSERT INTO stats (key,label,value,suffix) SELECT 'albums','Альбомов в дискографии',COUNT(*),'' FROM albums")
    conn.execute("INSERT INTO stats (key,label,value,suffix) SELECT 'tracks','Треков в базе',COUNT(*),'' FROM tracks")


ALBUM_NOTES = {  # заметки к страницам альбомов (по названию альбома)
 "The College Dropout": [("Люди", "Продюсер: в основном Kanye West. Гости: Jay-Z, Mos Def, Talib Kweli, Common, Jamie Foxx, Ludacris."), ("История", "«Through the Wire» записан после аварии 2002 года. Альбом получил Grammy как лучший рэп-альбом.")],
 "Late Registration": [("Люди", "Сопродюсер Jon Brion. Гости: Jamie Foxx, Adam Levine, Common, Nas, Jay-Z, Lupe Fiasco, Brandy."), ("История", "«Gold Digger» возглавил Billboard Hot 100; альбом взял Grammy как лучший рэп-альбом.")],
 "Graduation": [("История", "Вышел в один день с «Curtis» 50 Cent: «битва продаж», которую выиграл Kanye. Обложка Takashi Murakami."), ("Звук", "«Stronger» построен на сэмпле Daft Punk; синтезаторы и стадионные хуки повлияли на поп-рэп.")],
 "808s & Heartbreak": [("Звук", "Драм-машина Roland TR-808 и автотюн: холодные синтезаторы вместо привычных сэмплов."), ("Люди", "Гости: Kid Cudi, Young Jeezy, Lil Wayne, Mr Hudson.")],
 "My Beautiful Dark Twisted Fantasy": [("История", "Записывался на Гавайях. Pitchfork поставил максимальные 10.0. К «Runaway» вышел короткометражный фильм."), ("Люди", "Гости: Rick Ross, Jay-Z, Nicki Minaj, Kid Cudi, Bon Iver, Rihanna, Raekwon, Pusha T, Elton John.")],
 "Watch the Throne": [("Люди", "Kanye West и Jay-Z. Продюсеры: Hit-Boy, Q-Tip, Swizz Beatz."), ("История", "За «Ni**as in Paris» дуэт получил Grammy; трек исполняли на концертах по нескольку раз подряд.")],
 "Yeezus": [("Люди", "Исполнительный продюсер Rick Rubin; Daft Punk, Hudson Mohawke, Gesaffelstein, Arca, Mike Dean."), ("История", "Прозрачный футляр без обложки с красной лентой. Промо: проекции клипов на стены зданий.")],
 "The Life of Pablo": [("История", "Показан в Madison Square Garden вместе с Yeezy Season 3; после релиза альбом правили: миксы и треки менялись."), ("Люди", "Гости: Chance the Rapper, Kirk Franklin, The Weeknd, Rihanna, Kid Cudi, Frank Ocean, Sia, Kendrick Lamar.")],
 "Ye": [("История", "Семь треков, меньше 25 минут. Записан в Вайоминге; начало серии быстрых релизов лета 2018."), ("Звук", "Сырые семплы и «живой» микс, над которым работал Mike Dean.")],
 "Kids See Ghosts": [("Люди", "Kanye West и Kid Cudi. Гости: Pusha T, Ty Dolla $ign, Yasiin Bey."), ("Звук", "Психоделика, хоровые эффекты и компактные 23 минуты.")],
 "Jesus Is King": [("История", "Дебютировал на первом месте Billboard 200. Вышел вместе с IMAX-фильмом; рядом идёт серия Sunday Service."), ("Люди", "Гости: Clipse, Ty Dolla $ign, Kenny G, Fred Hammond, Ant Clemons.")],
 "Donda": [("История", "Назван в честь матери Kanye. Три прослушивания на стадионах Атланты и Чикаго; дебют на первом месте Billboard 200."), ("Люди", "Гости: Jay-Z, The Weeknd, Travis Scott, Playboi Carti, Kid Cudi, Don Toliver, Pop Smoke, Jay Electronica.")],
 "Vultures 1": [("Люди", "Проект ¥$: Kanye West и Ty Dolla $ign. Гости: Playboi Carti, Rich the Kid, North West."), ("История", "Вышел в феврале 2024 года; «Carnival» стал хитом Billboard Hot 100.")],
}


def add_notes(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS album_notes (album_id INTEGER, label TEXT, text TEXT)")
    if conn.execute("SELECT COUNT(*) FROM album_notes").fetchone()[0]:
        return
    for title, ns in ALBUM_NOTES.items():
        r = conn.execute("SELECT id FROM albums WHERE title = ?", (title,)).fetchone()
        if r:
            conn.executemany("INSERT INTO album_notes VALUES (?,?,?)", [(r[0], l, t) for l, t in ns])


_run = run


def run(conn):
    _run(conn)
    add_notes(conn)
