@echo off
chcp 65001 >nul
set /p SITE=Адрес сайта на GitHub Pages, например https://ник.github.io : 
py tools\build_static.py %SITE%
echo.
echo Готово: папка docs обновлена. Загрузите проект на GitHub.
pause
