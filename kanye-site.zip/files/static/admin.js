'use strict';
const status = $('#status'), key = $('#key');
key.value = sessionStorage.getItem('adm') || '';
key.addEventListener('input', () => sessionStorage.setItem('adm', key.value));
const fill = (s, items, label) => s.replaceChildren(...items.map((x) => { const o = el('option', '', label(x)); o.value = x.id; return o; }));
const hdr = () => (key.value ? { 'X-Admin-Key': encodeURIComponent(key.value), 'X-Admin-Request': '1' } : { 'X-Admin-Request': '1' });
async function send(url, form, ok) {
  status.textContent = 'Отправка…';
  const r = await fetch(url, { method: 'POST', body: new FormData(form), headers: key.value ? { 'X-Admin-Key': encodeURIComponent(key.value), 'X-Admin-Request': '1' } : { 'X-Admin-Request': '1' } });
  const j = await r.json().catch(() => ({}));
  status.textContent = r.ok ? '✓ ' + ok : '✗ ' + (j.error || 'Ошибка ' + r.status);
  return r.ok;
}
(async () => {
  const albums = await api('/api/albums');
  [$('#a1'), $('#a2'), $('#a3'), $('#a4')].forEach((s) => fill(s, albums, (a) => a.year + ' · ' + a.title));
  const tracks = async () => fill($('#t1'), await api('/api/tracks/' + $('#a1').value), (t) => t.track_no + '. ' + t.title);
  $('#a1').addEventListener('change', tracks); tracks();
  const tracks4 = async () => fill($('#t4'), await api('/api/tracks/' + $('#a4').value), (t) => t.track_no + '. ' + t.title);
  $('#a4').addEventListener('change', tracks4); tracks4();
  const bind = (id, url, ok, after) => $(id).addEventListener('submit', async (e) => {
    e.preventDefault();
    if (await send(url, e.target, ok)) { e.target.reset(); after && after(); }
  });
  $('#f-spa').addEventListener('submit', async (e) => {
    e.preventDefault(); status.textContent = 'Отправка…';
    const r = await fetch('/api/admin/spotify', { method: 'POST', body: new FormData(e.target), headers: hdr() }), j = await r.json().catch(() => ({}));
    status.textContent = r.ok ? '✓ Привязано треков: ' + j.mapped + ' из ' + j.tracks + ' (ссылок вставлено: ' + j.links + (j.album ? ', ссылка на альбом сохранена' : '') + '). ' + (j.links !== j.tracks ? 'Количество не совпало: проверьте порядок или задайте «Начать с трека №».' : '') : '✗ ' + (j.error || 'Ошибка ' + r.status);
  });
  $('#spa-clear').addEventListener('click', async () => {
    const fd = new FormData(); fd.append('album_id', $('#a3').value);
    const r = await fetch('/api/admin/spotify_clear', { method: 'POST', body: fd, headers: hdr() }); status.textContent = r.ok ? '✓ Spotify у альбома сброшен' : '✗ Ошибка ' + r.status;
  });
  bind('#f-spt', '/api/admin/spotify_track', 'ссылка Spotify привязана к треку');
  bind('#f-mp3', '/api/admin/preview', 'mp3 привязан к треку');
  bind('#f-track', '/api/admin/track', 'трек добавлен', tracks);
  bind('#f-album', '/api/admin/album', 'альбом добавлен, обновите страницу', () => setTimeout(() => location.reload(), 900));
  bind('#f-quote', '/api/admin/quote', 'цитата добавлена');
})().catch(() => { status.textContent = 'Не удалось загрузить данные: проверьте, что сервер запущен.'; });
